# Product SPEC

## Product Vision

## Problem

## Goals

## Non-goals

## Personas

## User Journeys

## MVP Scope

## Out of Scope

## Functional Requirements

## Business Rules

## Roles & Permissions

## Data Requirements

## Integrations

## Non-functional Requirements

## Failure Scenarios

## Success Criteria

## Assumptions

## Open Questions
