# US-XXX — Story Name

Role:
Goal:
Business Value:
Related Requirements:
Priority:
Dependencies:
Status: TODO

## Acceptance Criteria

Given
When
Then

## Definition of Ready
- [ ] Requirement linked
- [ ] Design exists
- [ ] Dependencies resolved
- [ ] Acceptance criteria testable

## Definition of Done
- [ ] Acceptance criteria met
- [ ] Unit tests
- [ ] Integration tests
- [ ] Relevant E2E
- [ ] Lint
- [ ] Typecheck
- [ ] Review
- [ ] QA
- [ ] Docs updated
