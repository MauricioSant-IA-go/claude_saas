| Table/Resource | Classification | SELECT | INSERT | UPDATE | DELETE | Tests |
|---|---|---|---|---|---|---|
