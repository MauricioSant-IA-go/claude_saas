| Route/Operation | Method | Exposure | Role/Capability | Tenant/Ownership | Validation | Rate/Abuse | Idempotency | Tests |
|---|---|---|---|---|---|---|---|---|
