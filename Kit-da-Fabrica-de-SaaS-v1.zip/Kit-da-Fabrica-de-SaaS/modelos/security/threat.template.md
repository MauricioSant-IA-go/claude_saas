# THREAT-XXX
Asset:
Entry point:
Scenario:
Impact:
Likelihood rationale:
Controls:
Verification tests:
Residual risk:
