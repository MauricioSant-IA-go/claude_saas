# Backend Architecture

## Architecture style
- Decision: Modular Monolith | Microservices | Hybrid
- Rationale:
- ADR:

## Modules / bounded contexts
| Module | Responsibility | Owns data | Public contracts | Dependencies |
|---|---|---|---|---|

## Trust boundaries

## Authentication

## Authorization / policy model

## Tenant isolation

## Database authorization / RLS

## Async jobs / queues

## Integrations

## Observability

## Failure modes

## Service extraction candidates
| Candidate | Driver | Extract now? | Reason |
|---|---|---|---|
