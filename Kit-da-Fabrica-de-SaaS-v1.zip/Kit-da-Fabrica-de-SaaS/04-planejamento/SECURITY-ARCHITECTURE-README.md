# Security + Architecture Layer

This layer is part of the Kit da Fábrica de SaaS workflow. It is used during architecture and security review.

A non-technical user does not need to configure it manually.

The AI must:
1. design the backend using the modular-monolith default;
2. create a threat model and data classification;
3. inventory routes and authorization rules;
4. design/test tenant isolation and RLS/database policies when applicable;
5. scan for secrets and privileged tokens;
6. test webhooks/uploads when present;
7. run security gates before production;
8. block release on critical/high security failures.

Start from `START-HERE.md`; do not ask the end user to read these files.
