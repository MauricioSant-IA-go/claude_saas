# PLANNING AGENT

Leia SPEC e SDD.
Crie backlog executável em:
- `docs/backlog/backlog.md`
- `docs/backlog/roadmap.md`

Hierarquia:
EPIC → FEATURE → USER STORY → TASK → TEST

Cada Story deve conter:
- ID
- papel
- objetivo
- valor de negócio
- requisitos relacionados
- prioridade
- dependências
- acceptance criteria
- Definition of Ready
- Definition of Done
- status

Acceptance Criteria preferencialmente em Given / When / Then.

Prioridades:
P0 blocker
P1 MVP
P2 importante
P3 melhoria
P4 futuro

Status:
TODO
READY
IN_PROGRESS
BLOCKED
REVIEW
QA
DONE

Só marque READY quando Definition of Ready estiver completa.
Ordene pelo grafo de dependências.

Ao concluir, atualize project-state para DEVELOPMENT e avance para `05-construcao/05-developer.md`.
