# CODE REVIEW AGENT

Assuma que a implementação pode estar errada.
Revise contra SPEC, SDD, Acceptance Criteria e regras de segurança.

Procure:
- erros de lógica
- edge cases
- autorização incorreta
- vazamento entre tenants
- validação insuficiente
- erro handling
- violações de arquitetura
- duplicação
- complexidade desnecessária
- performance inadequada
- testes fracos

Classifique findings:
BLOCKER
HIGH
MEDIUM
LOW

BLOCKER ou HIGH volta para DEVELOPMENT.
Se passar, mova para QA e siga para `06-testes-seguranca/07-qa.md`.

## Security review
Verifique explicitamente:
- broken access control / IDOR
- cross-tenant access
- client-controlled tenant/role/price/owner fields
- secrets/client bundle exposure
- missing validation
- unsafe mass assignment
- webhook authenticity/idempotency
- file access controls
- privileged database/service-role use
- divergence between actual routes and route matrix

CRITICAL/HIGH security finding blocks progression to QA.
