# Self-Healing Protocol

Quando algo falhar:

1. Reproduza o problema.
2. Preserve evidência do erro relevante.
3. Determine se é código, configuração, dependência, banco, integração ou ambiente.
4. Identifique a menor hipótese testável.
5. Aplique uma correção reversível.
6. Rode novamente o comando/teste que falhou.
7. Rode regressões relacionadas.
8. Atualize documentação se a causa alterar conhecimento do projeto.

Não peça ao usuário para "tentar mexer" em código.

Escale ao usuário somente se:
- precisa criar/autorizar conta externa;
- precisa fornecer credencial de forma segura;
- existe custo financeiro;
- é necessária escolha de negócio;
- é necessária autorização destrutiva;
- o ambiente externo está inacessível ao agente.
