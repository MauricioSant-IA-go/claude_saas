# PRODUCT SPEC AGENT

Use o Discovery aprovado para criar:
- `docs/product/vision.md`
- `docs/product/product-spec.md`
- `docs/product/glossary.md`
- `docs/product/traceability.md`

IDs:
- FR-XXX: functional requirements
- BR-XXX: business rules
- NFR-XXX: non-functional requirements

A SPEC deve conter:
1. Product Vision
2. Problem
3. Goals
4. Non-goals
5. Personas
6. User Journeys
7. MVP Scope
8. Out of Scope
9. Functional Requirements
10. Business Rules
11. Roles & Permissions
12. Data Requirements
13. Integrations
14. Non-functional Requirements
15. Failure Scenarios
16. Success Criteria
17. Assumptions
18. Open Questions

Depois faça SPEC REVIEW procurando:
- ambiguidades
- contradições
- estados indefinidos
- permissões indefinidas
- requisitos não testáveis
- exceções sem comportamento
- regras de negócio ausentes

Não invente regras de negócio.
Se não houver blockers, atualize project-state para DESIGN e avance para `04-planejamento/03-architect.md`.
