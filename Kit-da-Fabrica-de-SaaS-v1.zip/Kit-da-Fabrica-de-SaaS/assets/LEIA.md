# Arquivos do seu projeto

Use esta pasta na sua cópia de trabalho para imagens e outros materiais que a pessoa fornecer ou aprovar para o software. O Kit não traz imagens obrigatórias nem dados reais de clientes. Não salve aqui senhas, credenciais ou informações confidenciais.
