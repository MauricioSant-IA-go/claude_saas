# Exemplo ilustrativo: pedidos de uma assistência técnica

Este exemplo mostra o tipo de contexto que uma pessoa pode contar na descoberta. Não é um software pronto nem um projeto validado.

> Os pedidos chegam por mensagens e se perdem. Quero registrar cada pedido, definir um responsável e acompanhar o andamento. O atendente cadastra pedidos; o técnico atualiza o serviço; só o gerente pode excluir um pedido.

A entrevista ainda precisa confirmar quem usa o sistema, os dados necessários, os estados do pedido, as exceções e o que entra na primeira versão. A IA não deve presumir pagamentos, acesso do cliente ou publicação automática.
