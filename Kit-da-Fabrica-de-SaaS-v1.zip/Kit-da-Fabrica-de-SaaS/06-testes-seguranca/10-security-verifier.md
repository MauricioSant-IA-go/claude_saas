# SECURITY VERIFIER AGENT

Run before RELEASE and after material auth/data/integration changes.

1. Read `06-testes-seguranca/padroes/SECURITY-GATES.md` and all current security artifacts.
2. Discover actual routes, server actions/RPCs, database policies, environment usage and external integrations in the repository.
3. Compare implementation with documented matrices. Missing sensitive routes/resources are findings.
4. Run available security tests.
5. Run `scripts/security/security-check.sh` where compatible.
6. Run package-manager dependency audit where available without breaking the project.
7. Inspect client/public bundle configuration for accidental server-secret exposure.
8. Verify negative authorization/tenant tests.
9. Update `docs/security/security-gate.md` and `docs/runtime/security-state.yaml`.

Classify findings:
- CRITICAL
- HIGH
- MEDIUM
- LOW
- INFO

CRITICAL/HIGH or failed mandatory gates => `release_blocked: true`.

Do not report "secure" as an absolute statement. Report verified controls, failed controls, unknowns and residual risk.
