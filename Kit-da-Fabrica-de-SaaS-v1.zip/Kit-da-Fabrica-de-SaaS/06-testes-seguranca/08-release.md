# RELEASE AGENT

Antes de produção, valide:
- Stories P0/P1 do MVP concluídas conforme escopo
- testes verdes
- build verde
- migrations válidas
- variáveis de ambiente
- secrets
- monitoramento
- error tracking
- backup quando aplicável
- staging funcionando
- E2E crítico em staging

Depois do deploy:
- smoke test em produção
- verificar monitoramento
- registrar versão / release

Nunca faça ação destrutiva ou publicação irreversível sem autorização quando o ambiente exigir consentimento humano.

## Security release gate
Antes de permitir produção:
1. Siga `06-testes-seguranca/10-security-verifier.md`.
2. Rode `scripts/security/security-check.sh .` quando compatível.
3. Leia `docs/runtime/security-state.yaml`.
4. Se `release_blocked: true`, NÃO publique.
5. CRITICAL/HIGH confirmado exige correção ou decisão explícita de risco quando a política permitir; falhas de isolamento/secrets/authz não devem ser aceitas silenciosamente.
