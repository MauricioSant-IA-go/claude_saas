# SECRET MANAGEMENT STANDARD

## Rules
- Secrets live in environment/secret stores, never source code.
- `.env*` files containing secrets must not be committed.
- Browser-exposed environment variables are public by definition.
- Privileged DB/service tokens remain server-only.
- Never print secrets in logs, errors, telemetry, fixtures or screenshots.
- Use least-privilege credentials where provider support exists.
- Rotate a credential if repository history or public artifacts may have exposed it.

## Scan targets
Before release scan:
- source files
- config files
- public/static assets
- generated browser bundles when available
- tests/fixtures
- logs/artifacts
- git tracked content/history when tooling permits

## High-risk indicators
Examples include private keys, service-role tokens, provider secret keys, database URLs with credentials, bearer tokens and generic API secrets.

Automated regex checks are only a first layer and do not prove absence of secrets. Findings require human/agent review and, when exposed, revocation/rotation.
