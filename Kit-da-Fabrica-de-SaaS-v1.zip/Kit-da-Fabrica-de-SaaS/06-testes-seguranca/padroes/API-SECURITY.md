# API SECURITY STANDARD

- Validate inputs at the server boundary with schemas.
- Authorize every protected resource/action server-side.
- Return minimal data required by the caller.
- Avoid mass assignment: explicitly select mutable fields.
- Treat client-supplied tenant, owner, role, price and entitlement data as untrusted.
- Use stable error semantics without leaking secrets/internal stack traces to end users.
- Apply rate/abuse controls to authentication, password reset, verification, public search and expensive endpoints as appropriate.
- Use pagination and bounded limits for collection endpoints.
- Define idempotency for payment/order/job-creation endpoints where duplicate execution is harmful.
- Enforce request/body/file size limits.
- Use secure cookies and CSRF protections when authentication design requires them.
