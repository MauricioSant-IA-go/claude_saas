# RLS / DATABASE AUTHORIZATION STANDARD

Use database row-level security or equivalent database-native policies when the platform supports it and the application stores user-private or tenant-private rows.

## Table classification
Every table must be classified as one of:
- PUBLIC
- USER_PRIVATE
- TENANT_PRIVATE
- SYSTEM_ONLY

Document this in `docs/security/rls-matrix.md`.

## Policy requirements
For USER_PRIVATE or TENANT_PRIVATE tables define behavior for:
- SELECT
- INSERT
- UPDATE
- DELETE

Policies must identify the trusted identity source. Never trust `user_id`, `tenant_id`, `workspace_id` or role values supplied by the browser without server/database verification.

## Defense in depth
When RLS is used:
- application authorization is still required for business permissions
- privileged/service-role database access must remain server-only
- privileged paths must be narrowly scoped
- tests must include normal user credentials, not only admin/service credentials

## Required cross-tenant tests
For each TENANT_PRIVATE resource, where operations exist:
1. User A creates/owns a resource in Tenant A.
2. User B in Tenant B attempts direct SELECT by ID.
3. User B attempts UPDATE.
4. User B attempts DELETE.
5. User B attempts relationship traversal or list/filter access.
6. Expected result: no unauthorized data exposure or mutation.

Also test users in the same tenant with insufficient roles where role distinctions exist.

## Fail-closed requirement
Missing tenant context or missing identity must not broaden data access.
