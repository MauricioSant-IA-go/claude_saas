# ROUTE SECURITY STANDARD

Maintain `docs/security/route-matrix.md` for every server route, API handler, RPC/server action and externally reachable webhook.

Required columns:
- Route/Operation
- Method
- Exposure: PUBLIC | AUTHENTICATED | EXTERNAL_SIGNED | INTERNAL
- Required role/capability
- Tenant/ownership check
- Input validation
- Rate limit / abuse control when applicable
- Idempotency when applicable
- Audit event when applicable
- Security tests

## Required route tests
For protected routes test at least:
- unauthenticated request
- authenticated but unauthorized role
- valid role
- wrong tenant/resource ownership
- malformed input

For sensitive mutations also consider:
- duplicate request
- stale state/version
- excessive request frequency

Public routes must be explicit. A route not in the matrix is a security review failure for production-bound projects.
