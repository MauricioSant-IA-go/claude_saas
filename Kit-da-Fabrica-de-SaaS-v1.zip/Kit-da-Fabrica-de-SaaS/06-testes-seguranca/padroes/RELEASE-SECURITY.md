# SECURITY RELEASE PROCEDURE

Before PUBLISH:
1. Update threat model.
2. Update route matrix.
3. Update data and RLS classifications.
4. Run normal test suite.
5. Run security tests.
6. Run secret scanner.
7. Run dependency audit when package manager tooling supports it.
8. Inspect client bundle/environment exposure when applicable.
9. Verify production auth/cookie/CORS/header configuration.
10. Verify webhook secrets/signatures where applicable.
11. Verify tenant isolation and privileged admin flows.
12. Update `docs/security/security-gate.md` and `docs/runtime/security-state.yaml`.

Do not claim a scan proves the software is "secure". Report what was tested, what passed, what remains unknown and any accepted residual risks.
