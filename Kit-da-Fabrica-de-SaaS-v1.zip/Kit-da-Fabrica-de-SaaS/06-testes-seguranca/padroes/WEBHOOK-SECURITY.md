# WEBHOOK SECURITY STANDARD

For every external webhook:
- verify provider authenticity/signature using the raw payload when required
- reject invalid signatures
- validate timestamp/freshness when provider supports it
- record provider event ID
- make duplicate processing safe/idempotent
- avoid trusting mutable business values without validation
- acknowledge/retry according to provider semantics
- do not expose webhook secrets to clients

Required tests when applicable:
- valid signature
- missing signature
- invalid/tampered signature
- duplicate event
- stale/replay event where detectable
- handler retry
- malformed payload
