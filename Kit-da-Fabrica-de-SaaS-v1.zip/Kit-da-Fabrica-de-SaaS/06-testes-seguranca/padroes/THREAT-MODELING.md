# THREAT MODELING STANDARD

Generate `docs/security/threat-model.md` during DESIGN for production-bound projects.

For each relevant feature identify:
1. Assets
2. Actors
3. Trust boundaries
4. Entry points
5. Sensitive data
6. Privileged operations
7. External dependencies
8. Abuse/failure scenarios

Threat record format:

```text
THREAT-XXX
Asset:
Entry point:
Scenario:
Impact:
Likelihood rationale:
Controls:
Verification tests:
Residual risk:
```

Always consider:
- broken access control / IDOR
- cross-tenant access
- privilege escalation
- credential/token exposure
- injection and unsafe parsing
- webhook spoofing/replay
- unsafe file upload
- data deletion/recovery
- financial duplication or price manipulation
- SSRF where user-controlled URLs exist
- rate abuse / resource exhaustion
- dependency/integration failure

Threats must connect to concrete controls and tests.
