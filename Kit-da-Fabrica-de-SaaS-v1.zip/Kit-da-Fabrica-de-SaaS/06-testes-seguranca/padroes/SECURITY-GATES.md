# SECURITY GATES

A production release must pass applicable gates.

## GATE-S01 — Threat model
PASS when current architecture/features have a threat model with controls/tests for material threats.

## GATE-S02 — Route inventory
PASS when all externally reachable routes/operations are classified and protected as intended.

## GATE-S03 — AuthN/AuthZ
PASS when protected operations have negative and positive authorization tests.

## GATE-S04 — Tenant isolation
PASS when cross-tenant negative tests pass for tenant-private resources.

## GATE-S05 — RLS / database policy
Applicable when RLS/database-native policies are used or required. PASS when policies exist and user-context tests prove isolation.

## GATE-S06 — Secrets
PASS when automated/manual scans find no live privileged secret in tracked source, client bundle or logs. Any confirmed exposed credential requires rotation, not merely deletion.

## GATE-S07 — Dependency security
PASS when available package/security audits have no unresolved critical/high issue that is exploitable in the deployed context, or an explicit documented risk decision exists.

## GATE-S08 — Webhooks/integrations
Applicable when webhooks exist. PASS when authenticity, duplicate/idempotency and malformed input tests pass.

## GATE-S09 — Upload security
Applicable when uploads exist. PASS when type/size/access controls and cross-tenant file tests pass.

## GATE-S10 — Production configuration
PASS when debug/dev bypasses are disabled, secure environment/secrets are configured, error responses do not leak secrets, and required monitoring exists.

## Blocking policy
CRITICAL/HIGH confirmed findings or failed mandatory gates set RELEASE_BLOCKED=true.
