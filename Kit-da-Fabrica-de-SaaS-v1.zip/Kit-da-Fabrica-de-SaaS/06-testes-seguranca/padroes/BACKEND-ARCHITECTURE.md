# BACKEND ARCHITECTURE STANDARD

## Default architecture: Modular Monolith
A new SaaS MUST start as a modular monolith unless the SDD documents a concrete reason not to.

Recommended logical flow:

```text
Client
  ↓
Edge / Reverse Proxy
  ↓
HTTP/API Interface
  ↓
Authentication
  ↓
Authorization / Policy Layer
  ↓
Application Services / Use Cases
  ↓
Domain
  ↓
Repositories / Data Access
  ↓
Database Policies (RLS when applicable)
  ↓
PostgreSQL
```

Recommended module shape:

```text
src/
  modules/
    <module>/
      domain/
      application/
      infrastructure/
      interface/
      tests/
  shared/
  infrastructure/
  database/
```

## Boundaries
- Domain logic must not depend on UI components.
- Route handlers/controllers should be thin.
- Authorization belongs at the server trust boundary, not only in UI visibility logic.
- Data access must be centralized enough to make tenant/ownership enforcement auditable.
- External integrations must be wrapped behind explicit adapters/clients.
- Cross-module dependencies must be intentional and documented.

## Async workloads
Use queues/workers only when required by latency, retryability, workload duration or independent scaling.

```text
Application → Event/Job → Queue → Worker → External Service
```

Jobs should be idempotent when retries can occur.

## Microservice extraction criteria
Do NOT create a microservice merely because a domain module exists.
A service becomes a candidate only when one or more strong drivers exist:
- materially independent scaling profile
- long-running or compute-intensive workloads
- independent reliability/SLA requirement
- hard security/isolation boundary
- independent deployment cadence with real organizational value
- specialized infrastructure/runtime
- clear ownership and stable service boundary

Before extraction create an ADR containing:
- driver
- bounded context
- API/event contract
- data ownership
- consistency model
- failure modes
- observability
- deployment model
- migration/rollback plan

## Data ownership for services
If microservices are introduced, avoid shared-table ownership across services. Each service must have explicit data ownership. Cross-service reads/writes use contracts, events, replicated read models or another documented mechanism.
