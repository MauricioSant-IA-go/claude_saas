# FILE UPLOAD SECURITY STANDARD

Treat uploads as hostile input.

When uploads exist:
- allowlist expected types/extensions
- enforce file size limits
- generate server-controlled object names/paths
- prevent path traversal
- store separately from executable application code
- do not trust browser MIME alone
- prefer signed upload/download mechanisms for private objects
- enforce tenant/owner authorization on download
- consider malware/content scanning based on risk profile
- strip or safely handle dangerous active formats when relevant
- define retention/deletion policy

Test unauthorized access to private files across users/tenants.
