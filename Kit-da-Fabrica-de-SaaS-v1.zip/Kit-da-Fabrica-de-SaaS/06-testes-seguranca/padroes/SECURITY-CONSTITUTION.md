# SECURITY CONSTITUTION — VIBE-SPEC OS

Security is a release requirement, not an optional enhancement.

## Non-negotiable rules
1. Deny by default. Public access must be explicit.
2. Authentication is not authorization. Every protected operation must authorize the action and resource.
3. Multi-tenant access must be enforced server-side and, when supported by the database, reinforced by RLS or equivalent database policy.
4. Never ship server secrets, privileged tokens, service-role credentials or private keys to browser/client bundles.
5. Never trust identifiers, roles, prices, tenant IDs or ownership claims supplied by the client.
6. Validate all untrusted input at trust boundaries.
7. Destructive and financially relevant operations require explicit authorization, safe retry behavior and auditability where appropriate.
8. Webhooks require authenticity verification, replay/duplicate protection where supported, and idempotent processing.
9. File uploads are untrusted input and must be restricted by size/type and isolated from executable application code.
10. Security defects rated CRITICAL or HIGH block release.

## Required security artifacts
Every production-bound project must maintain, when applicable:
- `docs/security/threat-model.md`
- `docs/security/data-classification.md`
- `docs/security/route-matrix.md`
- `docs/security/rls-matrix.md`
- `docs/security/secrets-inventory.md`
- `docs/security/security-test-plan.md`
- `docs/security/security-gate.md`

## Required test classes
- authentication
- authorization
- horizontal access / IDOR
- tenant isolation
- RLS/database policies when used
- route protection
- input validation
- webhook authenticity/idempotency when used
- secret exposure scanning
- dependency audit when tooling is available
- security headers/cookie settings when applicable

## Release rule
No production release while `docs/runtime/security-state.yaml` reports a blocking gate as FAIL or UNKNOWN for an applicable control.
