# MULTI-TENANCY SECURITY STANDARD

If more than one customer/account/workspace exists, tenant isolation is a critical security boundary.

## Rules
- Derive trusted user identity from verified authentication context.
- Resolve tenant membership server-side.
- Never authorize from a browser-supplied tenant ID alone.
- Every tenant-owned record needs explicit ownership semantics.
- Prefer database constraints and RLS/DB policies as defense in depth when supported.
- Background jobs must carry trusted tenant context.
- Cache keys, object storage paths and search indexes must include safe tenant scoping when they can contain tenant-private data.

## Mandatory negative tests
- direct resource ID substitution
- list/filter query across tenant
- update/delete across tenant
- private file download across tenant
- background/job result access across tenant
- role downgrade/escalation cases
