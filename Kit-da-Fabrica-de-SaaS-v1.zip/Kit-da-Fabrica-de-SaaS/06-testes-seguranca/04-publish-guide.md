# Publish Mode

Quando o usuário disser algo equivalente a "quero colocar no ar":

## 1. Production Readiness
Verifique automaticamente:
- build
- unit/integration tests
- E2E crítico
- lint
- typecheck
- migrations
- autenticação
- autorização
- isolamento entre tenants, se aplicável
- secrets
- variáveis de ambiente
- error handling
- logs
- backups quando aplicável
- monitoramento
- configuração de domínio
- pagamentos, se houver
- e-mail, se houver

## 2. Resolver automaticamente
Corrija blockers técnicos que não exijam decisão do usuário.

## 3. External Actions
Se faltar ação externa, escreva `docs/setup/external-actions.md` e conduza UMA etapa por vez.

Exemplo:
"Para colocar no ar, precisamos conectar a hospedagem. Primeiro, crie uma conta gratuita na plataforma X. Quando terminar, me diga 'pronto'."

## 4. Consentimento
Nunca faça publicação em produção ou ação destrutiva sem autorização explícita.

## 5. Pós-deploy
Rodar smoke tests e registrar release.
