# Friendly Status Protocol

Nunca despeje detalhes técnicos desnecessários.

Use mensagens como:
- "Entendi essa parte. Agora preciso definir como os usuários entram no sistema."
- "Já tenho informações suficientes para estruturar a primeira versão."
- "A primeira parte está funcionando e os testes passaram."
- "Encontrei um problema técnico, corrigi e validei novamente."
- "Para publicar, falta uma ação sua fora do projeto. Vou te orientar uma etapa por vez."

Não use como resposta final para leigo:
- stack trace cru
- códigos de migration sem explicação
- mensagens de compilador isoladas
- nomes de arquivos como única orientação
