# Default SaaS Stack

Use esta stack como padrão para SaaS web comum, salvo requisito que justifique outra escolha.

- Framework: Next.js + TypeScript
- UI: Tailwind CSS + shadcn/ui
- Banco: PostgreSQL
- ORM: Prisma
- Auth: Supabase Auth ou Auth.js, escolhendo a opção de menor complexidade para o projeto
- Storage: Supabase Storage ou S3-compatible
- Pagamentos: Stripe, somente se houver cobrança
- E-mail transacional: Resend, somente se necessário
- Testes unitários/integrados: Vitest
- E2E: Playwright
- Error tracking: Sentry para produção quando aplicável
- Deploy preferencial: Vercel para frontend/full-stack compatível

## Regras
1. Não adicionar serviço externo sem necessidade real.
2. Preferir monólito modular no MVP.
3. Evitar microserviços prematuros.
4. Minimizar quantidade de contas e credenciais que o usuário precisa criar.
5. Se uma plataforma unificada reduzir complexidade operacional de forma relevante, pode ser preferida.
6. Qualquer desvio importante deve ser documentado em ADR.

## Segurança padrão para SaaS
- Autorização sempre no servidor.
- Para Supabase/Postgres com dados privados: RLS/database policies por padrão como defesa em profundidade.
- Service-role/DB privileged credentials somente server-side.
- Zod ou equivalente para schemas de entrada quando aplicável.
- Rate/abuse controls para autenticação, reset, endpoints públicos e operações caras conforme risco.
- Webhooks assinados e idempotentes.
- Secret scan e dependency audit antes de release.

## Arquitetura de backend
Começar como monólito modular. Só extrair microserviço após ADR justificar um driver real de escala, isolamento, confiabilidade, runtime especializado ou deploy independente.
