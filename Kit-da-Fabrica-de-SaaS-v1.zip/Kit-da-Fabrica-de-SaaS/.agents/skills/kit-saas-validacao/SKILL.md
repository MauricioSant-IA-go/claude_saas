---
name: kit-saas-validacao
description: Revise testes, permissões, segurança e prontidão para publicação de um software construído com o Kit da Fábrica de SaaS, sem publicar automaticamente.
---

# Validação do Kit

Quando a pessoa pedir revisão, testes ou preparação para colocar no ar, leia `06-testes-seguranca/07-qa.md`, `06-testes-seguranca/10-security-verifier.md`, `06-testes-seguranca/08-release.md` e os padrões aplicáveis em `06-testes-seguranca/padroes/`.

Execute as verificações compatíveis com o projeto e compare resultado real com especificação e critérios de aceitação. Registre o que passou, falhou ou não pôde ser testado; controles críticos desconhecidos não equivalem a aprovação. Atualize os documentos de segurança e o estado do projeto.

Se a pessoa pedir publicação, use também `06-testes-seguranca/04-publish-guide.md` para listar bloqueios, contas, custos e ações externas. Não publique, contrate serviços ou exponha dados sem autorização específica para essas ações.
