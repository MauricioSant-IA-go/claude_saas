---
name: kit-saas-planejamento
description: Planeje arquitetura, segurança e backlog do Kit da Fábrica de SaaS quando a especificação do produto estiver validada e a construção ainda não tiver começado.
---

# Planejamento do Kit

Leia `04-planejamento/03-architect.md`, `04-planejamento/09-security-architect.md`, `04-planejamento/04-planner.md` e os padrões aplicáveis em `06-testes-seguranca/padroes/`. Use a especificação aprovada em `docs/product/` como fonte do que construir.

Escolha soluções técnicas reversíveis com simplicidade, segurança e custo operacional razoável. Registre arquitetura, dados, fluxos, riscos, decisões e backlog em `docs/`. Não altere regras de negócio silenciosamente nem pule a análise de segurança quando houver dados privados, pagamentos ou integrações.

Apresente à pessoa um plano por etapas, com escolhas que afetem custo, acesso ou escopo explicadas sem jargão. Peça validação das decisões materiais antes de iniciar a implementação.
