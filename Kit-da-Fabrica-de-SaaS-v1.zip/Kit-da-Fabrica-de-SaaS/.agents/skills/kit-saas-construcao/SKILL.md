---
name: kit-saas-construcao
description: Construa, altere ou corrija uma etapa do software com o Kit da Fábrica de SaaS após haver plano aprovado, mantendo testes, revisão e estado do projeto.
---

# Construção do Kit

Leia `docs/project-state.md`, a especificação, o backlog e os materiais de `05-construcao/` relevantes à solicitação. Use `05-construcao/05-developer.md` para implementação, `05-construcao/06-reviewer.md` para revisão e `05-construcao/03-self-healing.md` quando algo falhar.

Trabalhe por unidades pequenas e verificáveis. Registre o comportamento esperado, implemente, execute testes disponíveis e confira regressões relacionadas. Para pedidos novos fora da especificação, faça análise de impacto e atualize os documentos antes de construir.

Mostre uma prévia local quando possível e explique o que funciona, o que não foi verificado e o próximo passo. Atualize `docs/project-state.md` e o backlog. Esta skill não autoriza publicação ou contratação de serviços externos.
