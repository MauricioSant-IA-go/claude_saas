---
name: kit-saas-descoberta
description: Conduza a entrevista inicial do Kit da Fábrica de SaaS quando uma pessoa trouxer uma ideia de software ou precisar redefinir o problema antes de especificar o produto.
---

# Descoberta do Kit

Leia `START-HERE.md`, `02-descoberta/01-interview-engine.md`, `02-descoberta/01-discovery.md` e `docs/runtime/discovery-state.yaml` a partir da raiz do projeto.

Comece entendendo o negócio, não escrevendo código. Faça até três perguntas por rodada em linguagem comum. Diferencie respostas confirmadas, hipóteses e lacunas; não escolha regras de negócio pelo usuário.

Registre o entendimento nos documentos de trabalho e apresente um resumo curto com problema, usuários, jornada, primeira versão, regras e pontos em aberto. Peça correção ou validação explícita. Só encaminhe para especificação depois da validação e quando não houver lacuna de negócio que altere o escopo.
