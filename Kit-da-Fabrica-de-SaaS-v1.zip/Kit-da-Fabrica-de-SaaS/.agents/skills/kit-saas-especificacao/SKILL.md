---
name: kit-saas-especificacao
description: Transforme a descoberta validada do Kit da Fábrica de SaaS em especificação, regras e escopo da primeira versão antes do planejamento técnico.
---

# Especificação do Kit

Use esta skill após a pessoa validar o resumo da descoberta, ou quando pedir mudança de escopo antes da construção. Leia `03-especificacao/02-spec.md`, os registros de descoberta e os modelos em `modelos/` que forem necessários.

Atualize `docs/product/vision.md`, `docs/product/product-spec.md`, `docs/product/glossary.md` e `docs/product/traceability.md` conforme as evidências. Separe fatos aprovados, suposições e decisões pendentes. Deixe claro o que entra na primeira versão e o que fica de fora.

Mostre as regras e o escopo em linguagem de negócio para validação. Não trate uma especificação escrita pela IA como aprovação do usuário; encaminhe à arquitetura somente após revisão das decisões relevantes.
