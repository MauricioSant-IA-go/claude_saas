# Change Requests

New product scope outside the approved SPEC should be documented as CR-XXX.md before implementation.
