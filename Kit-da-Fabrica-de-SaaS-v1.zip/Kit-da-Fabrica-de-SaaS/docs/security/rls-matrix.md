# RLS / Database Policy Matrix

| Table/Resource | Classification | SELECT | INSERT | UPDATE | DELETE | Tests |
|---|---|---|---|---|---|---|
