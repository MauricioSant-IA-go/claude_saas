# Secrets Inventory

Document required secret *names and purpose only*. Never store secret values here.
