# Data Classification

Classify data by sensitivity and retention requirements during DESIGN.
