# Critical E2E Flows

To be defined after Product SPEC.
