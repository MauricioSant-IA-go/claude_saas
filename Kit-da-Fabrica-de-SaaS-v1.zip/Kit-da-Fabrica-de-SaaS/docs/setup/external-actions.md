# External Actions

Nenhuma ação externa necessária ainda.

Este arquivo deve conter somente ações que inevitavelmente dependem do usuário, como criação de conta, autorização, domínio, billing ou secret externo.

Sempre conduzir uma ação por vez.
