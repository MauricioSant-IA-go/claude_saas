#!/usr/bin/env bash
set -uo pipefail
ROOT="${1:-.}"
cd "$ROOT" || exit 1
FAIL=0

run() {
  echo "\n== $1 =="
  shift
  "$@" || FAIL=1
}

run "Secret scan" bash scripts/security/scan-secrets.sh .

if [ -f package.json ]; then
  if command -v npm >/dev/null 2>&1 && [ -f package-lock.json ]; then
    echo "\n== npm dependency audit =="
    npm audit --audit-level=high || FAIL=1
  elif command -v pnpm >/dev/null 2>&1 && [ -f pnpm-lock.yaml ]; then
    echo "\n== pnpm dependency audit =="
    pnpm audit --audit-level high || FAIL=1
  elif command -v yarn >/dev/null 2>&1 && [ -f yarn.lock ]; then
    echo "\n== yarn dependency audit =="
    yarn npm audit --severity high || FAIL=1
  else
    echo "[security] package manager audit skipped: compatible lockfile/tool not detected"
  fi
fi

for f in docs/security/threat-model.md docs/security/route-matrix.md docs/security/security-test-plan.md; do
  if [ ! -s "$f" ]; then
    echo "[security] missing required artifact: $f"
    FAIL=1
  fi
done

if [ "$FAIL" -ne 0 ]; then
  echo "\nSECURITY CHECK: FAIL"
  exit 2
fi

echo "\nSECURITY CHECK: PASS (basic automated gate only; repository-specific security tests still required)"
