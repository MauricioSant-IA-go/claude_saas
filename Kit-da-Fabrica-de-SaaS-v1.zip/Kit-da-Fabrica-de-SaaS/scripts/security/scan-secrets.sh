#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
cd "$ROOT"

echo "[security] scanning tracked/project text for high-risk secret patterns"
PATTERN='(-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----|SUPABASE_SERVICE_ROLE_KEY\s*=|AWS_SECRET_ACCESS_KEY\s*=|DATABASE_URL\s*=.*://[^[:space:]]+:[^[:space:]@]+@|(^|[^A-Za-z0-9_])(sk_live_|rk_live_)[A-Za-z0-9_-]+|(^|[^A-Za-z0-9_])Bearer[[:space:]]+[A-Za-z0-9._~+/=-]{20,}|(API_KEY|SECRET|TOKEN)[[:space:]]*=[[:space:]]*[^$][^[:space:]]{12,})'

EXCLUDES=(--exclude-dir=.git --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=dist --exclude-dir=build --exclude='*.lock' --exclude='scan-secrets.sh')
set +e
grep -RInE "${EXCLUDES[@]}" "$PATTERN" .
RC=$?
set -e
if [ "$RC" -eq 0 ]; then
  echo "[security] possible secret material found. Review every finding; rotate any confirmed exposed credential."
  exit 2
elif [ "$RC" -eq 1 ]; then
  echo "[security] no high-risk pattern matched by this basic scanner"
  exit 0
else
  echo "[security] scanner error"
  exit "$RC"
fi
